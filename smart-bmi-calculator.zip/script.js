function calculateBMI() {
  let weight = document.getElementById("weight").value;
  let height = document.getElementById("height").value;

  if (!weight || !height || weight <= 0 || height <= 0) {
    alert("Please enter valid weight and height values.");
    return;
  }

  height = height / 100; // convert cm to meters
  let bmi = weight / (height * height);
  bmi = bmi.toFixed(2);

  let message = "";
  if (bmi < 18.5) message = "Underweight 🥦 – Eat healthy!";
  else if (bmi < 24.9) message = "Normal ✅ – Keep it up!";
  else message = "Overweight ⚠️ – Try some exercise!";

  document.getElementById("result").innerText = `Your BMI is ${bmi}\n${message}`;

  saveToHistory(bmi);
  showHistory();
}

function saveToHistory(bmi) {
  const time = new Date().toLocaleString();
  let history = JSON.parse(localStorage.getItem("bmiHistory")) || [];
  history.unshift({ bmi, time }); // add to the top
  history = history.slice(0, 5); // keep last 5 only
  localStorage.setItem("bmiHistory", JSON.stringify(history));
}

function showHistory() {
  let history = JSON.parse(localStorage.getItem("bmiHistory")) || [];
  let list = document.getElementById("history");
  list.innerHTML = "";
  history.forEach(entry => {
    const li = document.createElement("li");
    li.textContent = `${entry.time} → BMI: ${entry.bmi}`;
    list.appendChild(li);
  });
}

// Load history on page load
showHistory();